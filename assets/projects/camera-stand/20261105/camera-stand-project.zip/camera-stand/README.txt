Cork Robotics - Camera stand, styled edition
Version: 2026-11-05 | Dimensions in millimeters
https://corkrobotics.com/projects/camera-stand

START HERE
Open assembly_guide.pdf for the illustrated assembly sequence and rod sorting card.
Print the guide at 100% / actual size if using its scale references.

FILES
PHONE_STAND_STYLED_assembly.step: editable CAD assembly with separate components.
assembly.3mf: assembled model.
print/: five individual STL parts and a 3MF plate with print orientations.
assembly_plot.pdf and assembly_plot/sheet_01.svg: assembly drawing.
exploded.png: exploded assembly reference.

PRINT AND ASSEMBLE
Designed for PLA without supports. Clamp and holder print on their sides;
screw prints knob-down. The 3MF is a model layout, not pre-sliced G-code;
select settings appropriate to your printer and filament.
Also needed: 2 mm diameter steel rod, cut to 44.0 mm and 28.8 mm.
Allow at least 75 mm of rod stock for cuts, then file and deburr the ends.

FIT
Designed around an iPhone 16 in an approximately 14 mm-thick case and a
0.75-inch (19.05 mm) tabletop. Nine positions: upright and 12/24/36/48 degrees
each way. At the furthest forward tilt, route the charging cable out the front.
Adapt the STEP model for other devices or dimensions.

EDITION
This version keeps the mechanism of the original stand with a refined outline.
The supplied design notes mark this styled edition as not yet test-printed.
Socket clearance (0.25 mm) and thread clearance (0.3 mm) may need tuning.
