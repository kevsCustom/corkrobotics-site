"""expand + check + export a raw spec: build.py <dir with raw.json> <out subdir>"""
import json
import shutil
import sys
import time
from pathlib import Path

SVC = "/Users/kevincorsmeier/Documents/GitHub/drawBot/.claude/worktrees/electrical/drawBotStudyService"
sys.path.insert(0, SVC)
from study_service.partmodel import expand, mechanism  # noqa: E402

S = Path(sys.argv[1])
out = S / sys.argv[2]
raw = json.loads((S / "raw.json").read_text())
shutil.rmtree(out, ignore_errors=True)
t = time.time()
spec = expand.expand(raw)
print("expanded", f"{time.time() - t:.0f}s", flush=True)
if "--check-only" in sys.argv:
    b = mechanism.build(spec)
    print("built", f"{time.time() - t:.0f}s", flush=True)
    r = mechanism.check(b)
    out.mkdir(parents=True, exist_ok=True)
    (out / "report.json").write_text(json.dumps(r, indent=1))
    (out / "spec.json").write_text(json.dumps(spec, indent=1))
else:
    r = mechanism.run(spec, out, None)
print("ok", r["ok"], f"{time.time() - t:.0f}s")
for p in r["problems"]:
    print("PROBLEM", p[:700])
for n in spec.get("expand_notes", []):
    print("NOTE", n[:300])
for n in r["notes"]:
    print("CHECKNOTE", n[:300])
