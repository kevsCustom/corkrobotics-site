import json, shutil, sys
from pathlib import Path
import cv2
sys.path.insert(0, "/Users/kevincorsmeier/Documents/GitHub/drawBot/.claude/worktrees/electrical/drawBotStudyService")
from study_service.partmodel import mechanism as M, explode, step_export

src = Path(sys.argv[1]) / "out"
D = Path(sys.argv[2])
D.mkdir(parents=True, exist_ok=True)
spec = json.loads((src / "spec.json").read_text())
b = M.build(spec)
files = explode.write(b, D, sheet=True)
HEAD = {"can", "fabric", "face_frame", "bolt", "tilt_knob", "tilt_rosette"}
def grp(n):
    p = next(q for q in spec["parts"] if q["name"] == n)
    if p.get("print", True) is False:
        return "4_hardware"
    if n in HEAD:
        return "1_light_head"
    if n in ("yoke", "mast"):
        return "2_yoke_mast"
    return "3_tripod"
print(step_export.export(b, D / "CAN_STUDIO_LIGHT_assembly.step", groups={n: grp(n) for n in b.parts},
                         name="Can_Studio_Light", max_tris=20_000))
(D / "print").mkdir(exist_ok=True)
for f in (src / "print").iterdir():
    shutil.copy(f, D / "print" / f.name)
for f in ("views.png", "report.json", "spec.json", "assembly.3mf"):
    shutil.copy(src / f, D / f)
print(files)
