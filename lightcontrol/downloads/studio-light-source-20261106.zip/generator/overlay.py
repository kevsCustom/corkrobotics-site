"""Sketch-read overlay: what each sketched label became."""
import sys
import cv2
import numpy as np
sk = cv2.imread(sys.argv[1])
views = cv2.imread(sys.argv[2])
out = sys.argv[3]
H, W = sk.shape[:2]
img = sk.copy()
notes = [((150, 250), (255, 60, 0), "FACE FRAME 200x200x5 + fabric, 8 M3 into heat-set inserts, 0.4 gap, ridge/V-groove bite"),
         ((560, 330), (0, 140, 0), "CAN 1.6 mm wall, 90 deep, 5 LED lanes, vents, cable exit + strain posts"),
         ((690, 740), (200, 0, 160), "TILT: 30 Hirth teeth (12 deg), printed bolt + knob; -36..+60 proven (clear -90..+90)"),
         ((690, 1060), (0, 0, 220), "SLIDE CLAMP: printed thumbscrew + captured nut on the column, 100 mm height travel"),
         ((640, 1440), (0, 120, 200), "3 LEGS 240 mm, 35 deg open, 2 mm lock pin locks open AND folded")]
# the drawn image is 1200 x 1600 portrait? map by fraction
for (x, y), col, t in notes:
    x = int(x * W / 1200)
    y = int(y * H / 1600)
    cv2.circle(img, (x, y), 14, col, 3)
    cv2.putText(img, t, (max(5, x - 140), y + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (255, 255, 255), 5, cv2.LINE_AA)
    cv2.putText(img, t, (max(5, x - 140), y + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.62, col, 2, cv2.LINE_AA)
dev = ["DEVIATION: pole moved under the can's centre (L-shaped yoke from the side pivot),",
       "so the tripod carries the light over its middle: tips at 17 deg instead of ~11 side-hung."]
for i, t in enumerate(dev):
    cv2.putText(img, t, (20, H - 60 + 28 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 5, cv2.LINE_AA)
    cv2.putText(img, t, (20, H - 60 + 28 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2, cv2.LINE_AA)
# 3/4 render beside it
crop = views[0:views.shape[0] // 7, 0:views.shape[1] // 2]
s = H / crop.shape[0]
crop = cv2.resize(crop, None, fx=s, fy=s)
cv2.imwrite(out, np.hstack([img, crop]))
