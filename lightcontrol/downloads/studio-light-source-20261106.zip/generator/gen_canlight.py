"""CAN STUDIO LIGHT (Kevin's sketch IMG_1656, 2026-11-06): a 200 x 200 mm soft-light "can" on a folding tripod.

head    can       thin-walled (1.8 mm) tapered box, open at the front: LED strip lanes on the back, vents top and
                  bottom near the back, a cable exit with a woven strain relief, a 14 mm front land with 8 M3 heat-set
                  inserts and a 1 mm tooth ridge that bites the fabric. On its +x side a hollow pad carries 30 face
                  (Hirth) teeth, 12 deg steps, cut straight into the can (40 deg flanks print upright).
        fabric    diffusion cloth pinched between the land and the face frame (0.4 mm gap, waved over the ridge).
        face_frame 200 x 200 x 5 mm frame, 8 counterbored M3 screws; a V groove over the ridge.
        bolt      printed tilt bolt: teardrop head keyed in the pad (cannot turn), plain shank through the teeth and
                  the yoke, coarse printed thread (3 mm pitch) out the far side.
        tilt_knob printed knob (internal thread): tighten = teeth locked; one turn back = teeth apart, re-index.
stand   yoke      L arm: the tilt rosette at the top of its upright, the mast socket at the end of its foot, which
                  runs under the can's centre so the tripod carries the light over its middle.
        tilt_rosette  the matching 30 teeth, printed flat, glued into a keyed pocket in the yoke.
        mast      printed 18 mm keyed (chamfered square) pole, slides in the column for height.
        column    printed tube (stands on its crown to print) with the slide-clamp collar (captured printed nut +
                  thumbscrew pressing the mast) and the three leg hinges (clevis ears, 5 mm steel hinge pins,
                  a stop face for the open position, lock holes for open and folded).
        leg_0..2  printed legs; 2 mm steel lock pins lock each one open (35 deg) or folded.

Frame: x right (the yoke side), y away from the viewer (the light shines toward -y), z up; table z = 0.
Usage: gen_canlight.py <out_dir>   -> <out_dir>/raw.json + meshes/*.stl"""
import json
import math
import sys
from pathlib import Path

import manifold3d as m3
import numpy as np
import trimesh

OUT = Path(sys.argv[1])
MESH = OUT / "meshes"
MESH.mkdir(parents=True, exist_ok=True)
SVC = "/Users/kevincorsmeier/Documents/GitHub/drawBot/.claude/worktrees/electrical/drawBotStudyService"
sys.path.insert(0, SVC)
from study_service.partmodel import brep, mechanism  # noqa: E402

SEG = 96
P = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}   # overrides from the tuning loop (y_p, x_c)

# ---------------------------------------------------------------- parameters ------------------------------------------
FACE, D_CAN, BACK = 200.0, 90.0, 146.0           # face 200 x 200 (Kevin), depth, back size
WALL = 1.6
R_FACE = 10.0                                    # corner radius of the face square
OPEN = 174.0                                     # light opening = frame opening (13 mm land)
LAND_D = 2.5                                     # land depth (y): a light flange; the 8 inserts get bosses
GAP = 0.4                                        # fabric gap (Kevin 0.3-0.5)
FRAME_T = 5.0
RIDGE_C, RIDGE_B, RIDGE_H = 89.5, 1.6, 1.0       # tooth ridge (centre half-size, base, height): 51 deg flanks
SCREW_C = 93.0                                   # screw centres, half-size
N_T, FLANK = 30, 40.0                            # Hirth teeth, flank angle from the face plane
R_TIN, R_TOUT = 8.0, 24.0
A_T = math.pi / N_T * math.tan(math.radians(FLANK)) / 2   # tooth amplitude per mm of radius (peak +A r, valley -A r)
TRUNC = 0.15                                     # tooth tips cut back 15 % (lands, no knife edges)
T_GAP = 0.15                                     # axial play between the two tooth rings
X_T = 99.0                                       # pitch plane of the teeth (just inside the face's x = 100 edge)
PAD_R, PAD_X0, POCK_R = 27.0, 70.0, 16.5
PLATE = 6.0
X_PF = X_T - A_T * R_TOUT - 0.05                # pad face: right at the teeth's outer valleys
X_PI = X_PF - PLATE                              # pad plate inner face (bolt head side)
HEAD_REC = 2.5
B_BASE = 3.0                                     # rosette base
X_RB = X_T + T_GAP + B_BASE                      # rosette back = yoke pocket floor
X_YI = X_RB - 2.0                                # yoke inner face (pocket 2 deep)
YOKE_T = 11.0
X_YO = X_YI + YOKE_T
R_POCK = 25.3
Y_P = float(P.get("y_p", 36.0))                  # pivot y: at the head's centre of mass (tuning loop)
# thread (eccentric circle twisted: round coarse thread)
PITCH, ECC, R_TH, TH_CLEAR = 3.0, 0.6, 5.0, 0.3
SHANK_R = 5.0
KNOB_T, KNOB_R = 14.0, 20.0
# stand
LEG_ANG = 35.0
LEG_L = 240.0                                    # hinge pin to foot tip
LEG_T, LEG_W0, LEG_W1 = 10.0, 16.0, 11.0
R_H = 24.0                                       # hinge pin radius from the column axis
EAR_IN, EAR_T, EAR_T_NEAR = 5.3, 6.5, 10.5                        # ear inner face (|t|), ear thickness
LOCK_D = 14.0                                    # lock hole below the pin along the leg
COL_R = 15.5
COL_H = 190.0
MAST_H = 9.0                                     # mast half width
MAST_DX, MAST_DY = 2.0, 2.4                      # mast corner chamfers (51 deg: prints lying on -y)
SLIDE = 0.3
SOCK = 0.15
SOCK_D = 30.0
X_C = float(P.get("x_c", 18.0))                  # column axis (under the light's centre of mass)
Y_C = Y_P
NUT_AF, NUT_T = 16.0, 7.0


def _r(v):
    return round(float(v), 3)


def save(man: m3.Manifold, name: str) -> str:
    me = man.to_mesh()
    p = MESH / f"{name}.stl"
    trimesh.Trimesh(np.asarray(me.vert_properties)[:, :3], np.asarray(me.tri_verts), process=False).export(p)
    return str(p)


def mesh_f(man, name, op="add"):
    return dict(op=op, shape="mesh", file=save(man, name))


def rrect(hx, hy, r, n=12, c=(0.0, 0.0)):
    """Rounded rectangle polygon (half sizes hx, hy, corner r)."""
    pts = []
    for cx, cy, a0 in ((hx - r, hy - r, 0), (-hx + r, hy - r, 90), (-hx + r, -hy + r, 180), (hx - r, -hy + r, 270)):
        for k in range(n + 1):
            a = math.radians(a0 + 90 * k / n)
            pts.append((c[0] + cx + r * math.cos(a), c[1] + cy + r * math.sin(a)))
    return pts


def dense(pts, step=2.0):
    """Points along a closed polygon every ``step`` mm (a smooth spline through them stays on the polygon)."""
    P_ = np.asarray(pts, float)
    seg = np.roll(P_, -1, axis=0) - P_
    ln = np.linalg.norm(seg, axis=1)
    keep = ln > 1e-9
    P_, seg, ln = P_[keep], seg[keep], ln[keep]
    cum = np.concatenate([[0.0], np.cumsum(ln)])
    total = cum[-1]
    n = max(12, int(round(total / step)))
    out = []
    for s in np.linspace(0.0, total, n, endpoint=False):     # evenly spaced along the perimeter
        i = min(int(np.searchsorted(cum, s, side="right") - 1), len(P_) - 1)
        t = (s - cum[i]) / ln[i]
        out.append(tuple(P_[i] + seg[i] * t))
    return out


def cs_pts(cs: m3.CrossSection):
    polys = cs.to_polygons()
    def area(p):
        return abs(sum(p[i][0] * p[(i + 1) % len(p)][1] - p[(i + 1) % len(p)][0] * p[i][1] for i in range(len(p)))) / 2
    big = max(polys, key=lambda p: area(p) if len(p) > 2 else 0)
    return [tuple(map(float, p)) for p in big]


def ccw(pts):
    a = sum(x0 * y1 - x1 * y0 for (x0, y0), (x1, y1) in zip(pts, pts[1:] + pts[:1]))
    return pts if a > 0 else pts[::-1]


def rprism(axis, w0, w1, outline, holes=(), fe=None, te=None, op="add"):
    """A rounded_prism whose outline is resampled evenly (the B-rep spline through uneven points overshoots), at the
    first spacing whose fillet/chamfer builds and meshes closed (OpenCascade's fillet on one periodic spline edge is
    fragile: the same outline fails at one spacing and builds at the next)."""
    last = None
    for step in (2.0, 4.0, 2.5, 3.5, 1.75, 3.0, 2.25):
        d = dict(op=op, shape="rounded_prism", axis=axis, **{"from": _r(w0), "to": _r(w1)},
                 outline=[[_r(u), _r(v)] for u, v in ccw(dense(list(outline), step))])
        if holes:
            d["holes"] = [[[_r(u), _r(v)] for u, v in ccw(dense(list(h), step))] for h in holes]
        if fe:
            d["from_edge"] = fe
        if te:
            d["to_edge"] = te
        try:
            m = brep.rounded_prism(d, mechanism._AXES)
            if m.status() == m3.Error.NoError and len(m.decompose()) == 1:
                return d
        except Exception as e:  # noqa: BLE001
            last = e
    raise RuntimeError(f"rounded_prism never built: {last}")


def prism(axis, w0, w1, profile, op="add", **kw):
    return dict(op=op, shape="prism", axis=axis, **{"from": _r(w0), "to": _r(w1)}, profile=profile, **kw)


def tip_pt(u, v, e=0.02):
    """A point as a profile (a tiny triangle) for hulls: a sharp tip."""
    return {"polygon": [[_r(u), _r(v - e)], [_r(u + e), _r(v)], [_r(u), _r(v + e)], [_r(u - e), _r(v)]]}


def poly(pts):
    return {"polygon": [[_r(a), _r(b)] for a, b in pts]}


def drill(p0, p1, r, op="cut", **kw):
    return dict(op=op, shape="drill", p0=[_r(v) for v in p0], p1=[_r(v) for v in p1], r=_r(r), **kw)


def frame_xz(hx, hz, r, y, n=10):
    """3D points of a rounded square in the x-z plane at depth y, centred on the head's axis line."""
    return [(x, y, ZP + z) for x, z in rrect(hx, hz, r, n)]


def hull3(*clouds):
    return m3.Manifold.hull_points([list(map(float, p)) for c in clouds for p in c])


def rot_about(man, axis_dir, deg, point):
    return mechanism._rotate(man, axis_dir, deg, point)


FOOT_R = LEG_W1 / 2


def leg_body_at(Z_H):
    """Leg 0 stowed (hanging straight down), pin along y at (X_C + R_H, Y_C, Z_H)."""
    px0 = X_C + R_H
    half0, half1 = LEG_W0 / 2, LEG_W1 / 2
    zf = Z_H - (LEG_L - FOOT_R)
    outline = [(px0 - half0, Z_H), (px0 - half0, Z_H - 20), (px0 - half1, zf)]
    outline += [(px0 + half1 * math.cos(math.radians(180 + 180 * k / 12)), zf + half1 * math.sin(math.radians(180 + 180 * k / 12)))
                for k in range(13)]
    outline += [(px0 + half1, zf), (px0 + half0, Z_H - 20), (px0 + half0, Z_H)]
    outline += [(px0 + 8 * math.cos(math.radians(a)), Z_H + 8 * math.sin(math.radians(a))) for a in range(10, 180, 10)]
    cs = m3.CrossSection([ccw(outline)]).offset(2.5, m3.JoinType.Round).offset(-2.5, m3.JoinType.Round)
    o = dense(cs_pts(cs), 1.0)
    s = dict(shape="rounded_prism", axis="y", **{"from": Y_C - LEG_T / 2, "to": Y_C + LEG_T / 2},
             outline=[[_r(u), _r(v)] for u, v in ccw(o)], from_edge={"chamfer": 0.8}, to_edge={"fillet": 1.5})
    m = brep.rounded_prism(s, mechanism._AXES)
    m = m - mechanism.shape(dict(shape="cylinder", c=[px0, 0, Z_H], axis="y", r=2.6, **{"from": Y_C - 10, "to": Y_C + 10}))
    m = m - mechanism.shape(dict(shape="cylinder", c=[px0, 0, Z_H - LOCK_D], axis="y", r=1.1, **{"from": Y_C - 10, "to": Y_C + 10}))
    return m


# ------------------------------------------------------------- heights ------------------------------------------------
FOOT_R = LEG_W1 / 2
# the open angle is where the leg's stub meets the stop face; then the hinge height puts the open feet on the table
_l0 = None
TH_STOP = None


def _stop_angle():
    """The lock pin holds the leg at LEG_ANG both ways (no separate stop: Kevin's sketch has 'locking legs');
    the hinge height puts the open feet on the table."""
    lg = leg_body_at(0.0)
    pin = [X_C + R_H, Y_C, 0.0]
    low = rot_about(lg, [0, -1, 0], LEG_ANG, pin).bounding_box()[2]
    return LEG_ANG, LEG_ANG, -low


TH_STOP, TH_OPEN, Z_H = _stop_angle()                                 # hinge pin height (feet on the table, open)
Z_C = Z_H + 22.0                                                     # column top (crown)
Z_A = Z_C + SOCK_D + 2.0                                              # yoke foot top
R_SWEEP = max(math.hypot(Y_P + FRAME_T + GAP, FACE / 2), math.hypot(D_CAN - 2 - Y_P, (BACK + 2 * 0.6) / 2 + 0.5))
ZP = Z_A + R_SWEEP + 5.0                                              # tilt axis height
AXIS_T = dict(point=[_r(X_T), _r(Y_P), _r(ZP)], dir=[1, 0, 0])

parts, joints, steps, motions, free, idioms = [], [], [], [], [], []


def part(name, features, **kw):
    d = dict(name=name, features=features, material=kw.pop("material", "PLA"), **kw)
    parts.append(d)
    return d


# ================================================================ HEAD ================================================
def s_out(y):
    return FACE - (FACE - BACK) * y / D_CAN


WALL_H = WALL / math.cos(math.atan((FACE - BACK) / 2 / D_CAN))       # wall thickness measured across x
outer = hull3(frame_xz(FACE / 2, FACE / 2, R_FACE, 0.0),
              frame_xz(s_out(D_CAN - 1.2) / 2, s_out(D_CAN - 1.2) / 2, R_FACE * 0.7, D_CAN - 1.2),
              frame_xz(s_out(D_CAN - 1.2) / 2 - 1.2, s_out(D_CAN - 1.2) / 2 - 1.2, R_FACE * 0.7 - 0.5, D_CAN))   # 1.2 mm back chamfer
h7 = OPEN / 2
y1 = LAND_D + 1.25 * ((FACE / 2 - WALL_H) - 0.3 * LAND_D - h7) / (1 + 1.25 * 0.3)
cav = (hull3(frame_xz(h7, h7, 4.0, -1.0), frame_xz(h7, h7, 4.0, LAND_D))
       + hull3(frame_xz(h7, h7, 4.0, LAND_D), frame_xz(s_out(y1) / 2 - WALL_H, s_out(y1) / 2 - WALL_H, 12.0, y1))
       + hull3(frame_xz(s_out(y1) / 2 - WALL_H, s_out(y1) / 2 - WALL_H, 12.0, y1),
               frame_xz(s_out(D_CAN - WALL) / 2 - WALL_H, s_out(D_CAN - WALL) / 2 - WALL_H, 8.0, D_CAN - WALL)))
can_shell = outer - cav
Y_BACK_IN = D_CAN - WALL
HB_IN = s_out(Y_BACK_IN) / 2 - WALL_H

# --- Hirth teeth (local frame: w along +x from the pitch plane, polar (u, v) = (y - Y_P, z - ZP)) -------------------


def hirth(base_depth, r_out=R_TOUT, r_in=R_TIN):
    R = r_out + 2.0
    O = (0.0, 0.0, 0.0)
    ang = [2 * math.pi * k / N_T for k in range(N_T)]
    V = [(-A_T * R, R * math.cos(a), R * math.sin(a)) for a in ang]
    Pk = [(A_T * R, R * math.cos(a + math.pi / N_T), R * math.sin(a + math.pi / N_T)) for a in ang]
    ring = [(-base_depth, R * math.cos(2 * math.pi * k / 120), R * math.sin(2 * math.pi * k / 120)) for k in range(120)]
    body = hull3([O], V, ring)
    teeth = [hull3([O, V[k], Pk[k], V[(k + 1) % N_T]]) for k in range(N_T)]
    body = m3.Manifold.batch_boolean([body] + teeth, m3.OpType.Add)
    c = A_T * (1 - TRUNC)
    Rb = R + 5
    top = hull3([O], [(c * Rb, Rb * math.cos(2 * math.pi * k / 120), Rb * math.sin(2 * math.pi * k / 120)) for k in range(120)],
                [(30.0, Rb * math.cos(2 * math.pi * k / 120), Rb * math.sin(2 * math.pi * k / 120)) for k in range(120)])
    body = body - top
    cyl = m3.Manifold.cylinder(base_depth + 10, r_out, r_out, 192).translate([0, 0, -base_depth - 5])
    hole = m3.Manifold.cylinder(base_depth + 20, r_in, r_in, 96).translate([0, 0, -base_depth - 10])
    # the cylinder is along local z: map (w,u,v) <- (z,x,y) by building it in (u,v,w) order
    cylw = cyl.transform([[0, 0, 1, 0], [1, 0, 0, 0], [0, 1, 0, 0]])
    holew = hole.transform([[0, 0, 1, 0], [1, 0, 0, 0], [0, 1, 0, 0]])
    return (body ^ cylw) - holew


def to_world_A(m):     # local (w, u, v) -> world (X_T + w, Y_P + u, ZP + v)
    return m.translate([X_T, Y_P, ZP])


teeth_A = to_world_A(hirth(3.0))
# rosette teeth: mirrored through the pitch plane, half a tooth round, T_GAP back
teeth_B_local = hirth(B_BASE).mirror([1, 0, 0])
teeth_B_local = mechanism._rotate(teeth_B_local, [1, 0, 0], 180.0 / N_T, [0, 0, 0])
teeth_B = teeth_B_local.translate([X_T + T_GAP, Y_P, ZP])

# --- pad on the +x wall --------------------------------------------------------------------------------------------
pad_prof = {"hull": [{"circle": {"c": [Y_P, ZP], "r": PAD_R}}, tip_pt(Y_P + PAD_R * 1.6, ZP)]}
pocket_prof = {"hull": [{"circle": {"c": [Y_P, ZP], "r": POCK_R}},
                        tip_pt(Y_P - POCK_R * 1.6, ZP)]}   # teardrop: roof = -y up


def teardrop_yz(r, c=(None, None), up=(-1.0, 0.0), grow=0.0):
    """A teardrop profile (u, v): its point toward ``up`` (the print's up in the profile plane)."""
    yc, zc = c
    rr = r + grow
    return {"hull": [{"circle": {"c": [_r(yc), _r(zc)], "r": _r(rr)}},
                     tip_pt(yc + up[0] * rr * 1.6, zc + up[1] * rr * 1.6)]}


HEAD_R = 8.0
SCREWS = [(sx * (SCREW_C - (1.5 if sx and sz else 0.0)), sz * (SCREW_C - (1.5 if sx and sz else 0.0)))
          for sx in (-1, 0, 1) for sz in (-1, 0, 1) if (sx, sz) != (0, 0)]   # corners 1 mm in (the wall tapers)
BOSS_R, BOSS_L = 4.65, 8.0
_boss = []
for x, z in SCREWS:      # insert bosses behind the land, a 50 deg cone under each (prints), kept inside the outer wall
    cy = m3.Manifold.cylinder(BOSS_L, BOSS_R, BOSS_R, 64)
    cn = m3.Manifold.cylinder(BOSS_R * 1.2, BOSS_R, 0.3, 64).translate([0, 0, BOSS_L])
    bz = (cy + cn).transform([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0]])      # z -> y
    _boss.append(bz.translate([x, 0.0, ZP + z]))
BOSSES = m3.Manifold.batch_boolean(_boss, m3.OpType.Add) ^ outer
can_f = [mesh_f(can_shell + BOSSES, "can_shell"),
         mesh_f(mechanism.prism(mechanism.profile(pad_prof), "x", PAD_X0, X_PF) - cav, "can_pad"),
         mesh_f(teeth_A, "can_teeth"),
         prism("x", PAD_X0 - 1, X_PI, pocket_prof, op="cut"),
         prism("x", X_PI - 0.01, X_PI + HEAD_REC, teardrop_yz(HEAD_R + 0.3, (Y_P, ZP)), op="cut"),
         prism("x", X_PI, X_T + 3, teardrop_yz(R_TH + ECC + 0.3, (Y_P, ZP)), op="cut")]
# fabric ridge on the land: a square ring with a triangular section (51 deg flanks, 0.1 mm land on top)
rb = RIDGE_B / 2
L_R = RIDGE_C + rb
LAND_T = 0.1


def tri_ring(g, y_base=0.0, ext=0.6):
    """The ridge ring grown by g along its flank normals (g = 0: the ridge itself), from y_base + ext (into the land)
    up to its top land at y_base - RIDGE_H - g: square, mitred corners, so ridge, fabric and groove all agree."""
    d = np.array([LAND_T / 2 - rb, -RIDGE_H])            # outer flank, base -> top, in (half-size, y)
    n = np.array([RIDGE_H, LAND_T / 2 - rb]) * -1.0
    n = np.array([-n[0], n[1]]) if n[0] < 0 else n
    n = np.array([abs(d[1]), -abs(d[0])]) / np.linalg.norm(d)   # outward: +half, -y
    def half_at(y, outer):
        b0 = np.array([RIDGE_C + rb, y_base]) if outer else np.array([RIDGE_C - rb, y_base])
        dd = d if outer else np.array([-d[0], d[1]])
        nn = n if outer else np.array([-n[0], n[1]])
        p0 = b0 + g * nn
        t = (y - p0[1]) / dd[1]
        return float(p0[0] + t * dd[0])
    y_top = y_base - RIDGE_H - g
    y_bot = y_base + ext
    outer = hull3(frame_xz(half_at(y_bot, True), half_at(y_bot, True), 0.0, y_bot, 1),
                  frame_xz(half_at(y_top, True), half_at(y_top, True), 0.0, y_top, 1))
    inner = hull3(frame_xz(half_at(y_bot + 1, False), half_at(y_bot + 1, False), 0.0, y_bot + 1, 1),
                  frame_xz(half_at(y_top - 1, False), half_at(y_top - 1, False), 0.0, y_top - 1, 1))
    return outer - inner


RIDGE = tri_ring(0.0, ext=0.6)
GROOVE = tri_ring(GAP, ext=0.6)
can_f.append(mesh_f(RIDGE, "can_ridge"))
# LED strip lanes on the back (ribs), 5 strips 10 mm wide, 120 long
LED_W, LED_T, LED_L = 10.0, 1.6, 120.0
LANES = [-48.0, -24.0, 0.0, 24.0, 48.0]
for zc in LANES:
    for s in (1, -1):
        zr = zc + s * (LED_W / 2 + 0.3 + 0.6)
        can_f.append(dict(op="add", shape="box", min=[-LED_L / 2 - 4, Y_BACK_IN - 2.0, ZP + zr - 0.6],
                          max=[LED_L / 2 + 4, Y_BACK_IN + 0.5, ZP + zr + 0.6]))
# vents: slots through the top and bottom walls near the back; the front end of each slot is pointed (prints)
VY0, VY1 = 45.0, 76.0
for xk in [-50 + 12.5 * k for k in range(9)]:
    sl = poly([(xk - 2, VY1), (xk - 2, VY0 + 2.4), (xk, VY0), (xk + 2, VY0 + 2.4), (xk + 2, VY1)])
    can_f.append(prism("z", ZP + 55, ZP + 105, sl, op="cut"))
    can_f.append(prism("z", ZP - 105, ZP - 55, sl, op="cut"))
# cable exit + woven strain relief (three capped posts the cable snakes round)
CAB = (-44.0, -63.0)
can_f.append(dict(op="cut", shape="cylinder", c=[CAB[0], 0, ZP + CAB[1]], axis="y", r=3.5, **{"from": Y_BACK_IN - 3, "to": D_CAN + 1}))
POSTS = [(-34.0, -60.0), (-26.0, -66.0), (-18.0, -60.0)]
# one lathe profile per post (r, depth from the back's inside): stem, 47 deg cone, cap
_post = m3.Manifold.revolve(m3.CrossSection([[[0.0, -0.5], [2.5, -0.5], [2.5, 6.6], [4.0, 8.4], [4.0, 9.9], [0.0, 9.9]]]), 64)
_posts = m3.Manifold.batch_boolean([_post.transform([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0]]).translate([px_, Y_BACK_IN, ZP + pz])
                                    for px_, pz in POSTS], m3.OpType.Add)
can_f.append(mesh_f(_posts, "can_cable_posts"))
can_f += [dict(op="cut", shape="cylinder", c=[_r(x), 0, _r(ZP + z)], axis="y", r=2.15, **{"from": -0.5, "to": 6.5})
          for x, z in SCREWS]
part("can", can_f, role="frame", color=[235, 235, 238], print_orientation={"down": [0, 1, 0]},
     check="the land is flat, the 8 inserts sit flush, the teeth on the side pad are crisp",
     fit_how="print it standing on its back (the open face up): no supports")
steps.append(dict(parts=["can"], move="+x", note="the light head is built on the bench, then hung on the yoke"))

# --- face frame + fabric + screws ------------------------------------------------------------------------------------
FY0, FY1 = -GAP - FRAME_T, -GAP
fr_out = dense(rrect(FACE / 2, FACE / 2, R_FACE, 8), 3.0)
fr_in = dense(rrect(OPEN / 2, OPEN / 2, 4.0, 6), 3.0)
FR_OUT_RZ = [(x, z + ZP) for x, z in fr_out]
FR_IN_RZ = [(x, z + ZP) for x, z in fr_in]
frame_f = [rprism("y", FY0, FY1, FR_OUT_RZ, holes=[FR_IN_RZ], fe={"fillet": 2.0}, te={"chamfer": 0.6})]
frame_f.append(mesh_f(GROOVE, "frame_groove", op="cut"))
part("face_frame", frame_f, role="other", color=[40, 42, 46], print_orientation={"down": [0, 1, 0]},
     check="lies flat; the V groove runs all round", fit_how="print it front face up (the groove on the bed)")
fab_f = [dict(op="add", shape="prism", axis="y", **{"from": -GAP, "to": 0.0},
              profile={"polygon": [[_r(x), _r(z)] for x, z in FR_OUT_RZ]})]
fab_f.append(mesh_f(GROOVE ^ m3.Manifold.cube([FACE + 2, 3.0, FACE + 2]).translate([-FACE / 2 - 1, -3.0, ZP - FACE / 2 - 1]), "fabric_bump"))
fab_f.append(mesh_f(RIDGE, "fabric_ridge_cut", op="cut"))
fab_f += [dict(op="cut", shape="cylinder", c=[x, 0, ZP + z], axis="y", r=1.7, **{"from": -5, "to": 1}) for x, z in SCREWS]
part("fabric", fab_f, role="held_item", print=False, color=[250, 250, 250],
     material="diffusion fabric (white ripstop / diffusion cloth, ~0.3-0.4 mm), cut 200 x 200 mm with 8 holes",
     check="pulled smooth and square before the frame screws are tightened")
joints.append(dict(a="fabric", b="can", type="contact_stop", located_by="pinched between the land (and its ridge) and the face frame; the 8 screws through it"))
for i, (x, z) in enumerate(SCREWS):
    idioms.append({"use": "screw_boss", "name": f"fs{i + 1}", "near": "face_frame", "far": "can",
                   "at": [_r(x), 0.0, _r(ZP + z)], "dir": "+y", "thread": "M3", "grip": FRAME_T + GAP, "boss": False})
# LED strips (bought): stuck between the lane ribs
for k, zc in enumerate(LANES):
    part(f"led_{k + 1}", [dict(op="add", shape="box", min=[-LED_L / 2, Y_BACK_IN - LED_T, ZP + zc - LED_W / 2],
                                max=[LED_L / 2, Y_BACK_IN, ZP + zc + LED_W / 2])],
         role="held_item", print=False, color=[250, 220, 120], mass_g=2.5,
         material=f"LED strip {LED_W:g} mm wide (12 V, adhesive back), 120 mm long", check="pressed flat between its ribs")
    joints.append(dict(a=f"led_{k + 1}", b="can", type="glued", located_by="laid between its two lane ribs (0.3 mm a side)"))

# --- bolt + knob ------------------------------------------------------------------------------------------------------


def thread_x(name, r, x0, x1, phase_x=0.0, yc=Y_P, zc=ZP):
    """Eccentric circle twisted one turn per PITCH along +x: a round coarse thread (phase fixed by absolute x)."""
    cs = m3.CrossSection.circle(r, 96).translate([ECC, 0.0]).rotate(360.0 * (x0 - phase_x) / PITCH)
    h = x1 - x0
    m = m3.Manifold.extrude(cs, h, int(h / PITCH * 48), 360.0 * h / PITCH)    # along local z
    m = m.transform([[0, 0, 1, 0], [1, 0, 0, 0], [0, 1, 0, 0]])                 # local z -> world x
    return m.translate([x0, yc, zc])


X_BH0 = X_PI - (4.5 - HEAD_REC)      # bolt head back face (inside the can)
X_TH0, X_TH1 = X_YO - 1.0, X_YO + KNOB_T + 2.0
bolt_f = [prism("x", X_BH0, X_PI + HEAD_REC, teardrop_yz(HEAD_R, (Y_P, ZP))),
          dict(op="add", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=SHANK_R, **{"from": X_PI, "to": X_TH0 + 0.5}),
          mesh_f(thread_x("bolt_thread", R_TH, X_TH0, X_TH1), "bolt_thread")]
part("bolt", bolt_f, role="other", color=[200, 150, 60], print_orientation={"down": [-1, 0, 0]},
     check="its teardrop head drops into the pad's recess and cannot turn", fit_how="print it head down")
joints.append(dict(a="bolt", b="can", type="keyed", located_by="its teardrop head in the pad's teardrop recess"))
steps.append(dict(parts=["bolt"], path=[dict(move="+y"), dict(move="+x", mm=48.0)],
                  note="from inside the can: in through the open front, then out through the pad until the head drops into its recess"))
knob_f = [dict(op="add", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=KNOB_R, **{"from": X_YO, "to": X_YO + KNOB_T})]
knob_f += [dict(op="cut", shape="cylinder", c=[0, Y_P + KNOB_R * math.cos(a), ZP + KNOB_R * math.sin(a)], axis="x", r=3.5,
                **{"from": X_YO - 1, "to": X_YO + KNOB_T + 1}) for a in (2 * math.pi * k / 8 for k in range(8))]
knob_f += [dict(op="cut", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=R_TH + ECC + 1.2, r_to=R_TH - 1.0, **{"from": X_YO - 0.01, "to": X_YO + 2.2}),
           dict(op="cut", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=R_TH - 1.0, r_to=R_TH + ECC + 1.2, **{"from": X_YO + KNOB_T - 2.2, "to": X_YO + KNOB_T + 0.01})]
knob_f.append(mesh_f(thread_x("knob_thread", R_TH + TH_CLEAR, X_YO - 1, X_YO + KNOB_T + 1), "knob_thread", op="cut"))
part("tilt_knob", knob_f, role="knob", color=[40, 42, 46], print_orientation={"down": [1, 0, 0]},
     check="turns onto the bolt by hand", fit_how="print it flat, outer face down")
joints.append(dict(a="tilt_knob", b="bolt", type="running", located_by="its thread"))

# ================================================================ STAND ===============================================


def mast_pts(off=0.0):
    h = MAST_H + off
    return [(h, -(h - MAST_DY)), (h, h - MAST_DY), (h - MAST_DX, h), (-(h - MAST_DX), h), (-h, h - MAST_DY),
            (-h, -(h - MAST_DY)), (-(h - MAST_DX), -h), (h - MAST_DX, -h)]


def at_c(pts):
    return [(X_C + x, Y_C + y) for x, y in pts]


# --- yoke -------------------------------------------------------------------------------------------------------------
YW = 15.0
up_cs = (m3.CrossSection.circle(R_POCK + 5.5, 128).translate([Y_P, ZP])
         + m3.CrossSection.square([2 * YW, ZP - (Z_A - 14)]).translate([Y_P - YW, Z_A - 14]))
up_cs = up_cs.offset(8, m3.JoinType.Round).offset(-8, m3.JoinType.Round).offset(-4, m3.JoinType.Round).offset(4, m3.JoinType.Round)       # concave fillets at the neck
UP_PTS = dense(cs_pts(up_cs), 2.5)
WIN = dense(rrect(6.0, (ZP - R_POCK - 12 - (Z_A + 8)) / 2, 6.0, 6,
                  c=(Y_P, (ZP - R_POCK - 12 + Z_A + 8) / 2)), 2.5)                # lightening window in the neck
X_SOCK0 = X_C - 9.15 - 11.0 - 6.0                                               # socket peak + 6 mm wall
arm_cs = m3.CrossSection([ccw([(X_SOCK0, Z_A), (X_YI + 3, Z_A), (X_YI + 3, Z_A - 14), (X_C + 16 + 24, Z_A - 14),
                           (X_C + 16, Z_C + 0.1), (X_SOCK0, Z_C + 0.1)])])
arm_cs = arm_cs.offset(3, m3.JoinType.Round).offset(-3, m3.JoinType.Round).offset(-3, m3.JoinType.Round).offset(3, m3.JoinType.Round)
ARM_PTS = dense(cs_pts(arm_cs), 2.5)
sock = [(x, y) for x, y in at_c(mast_pts(SOCK))] + [(X_C - 9.15 - 11.0, Y_C)]
yoke_f = [rprism("x", X_YI, X_YO, UP_PTS, holes=[WIN], fe={"fillet": 2.0}, te={"chamfer": 1.0}),
          rprism("y", Y_P - YW + 1.0, Y_P + YW - 1.0, ARM_PTS, fe={"chamfer": 1.0}, te={"chamfer": 1.0}),
          # rosette pocket + key slot (opens up as printed)
          prism("x", X_YI - 1, X_RB, {"union": [{"circle": {"c": [Y_P, ZP], "r": R_POCK}},
                                                {"rect": {"min": [Y_P - 3.15, ZP], "max": [Y_P + 3.15, ZP + R_POCK + 3.0]}}]}, op="cut"),
          dict(op="cut", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=SHANK_R + 1.0, **{"from": X_YI - 1, "to": X_YO + 1}),
          prism("z", Z_C - 1, Z_C + SOCK_D, {"hull_points": [[_r(x), _r(y)] for x, y in sock]}, op="cut")]
PIN_Z = Z_C + SOCK_D / 2
yoke_f.append(drill([X_C, Y_C - YW, PIN_Z], [X_C, Y_C + YW - 2.2, PIN_Z], 1.0, up=[-1, 0, 0]))   # blind at +y
part("yoke", yoke_f, role="frame", color=[40, 42, 46], print_orientation={"down": [1, 0, 0]},
     check="the rosette pocket and the mast socket are clean; the bolt hole is round",
     fit_how="print it lying on its outer (knob) face: the foot stands up, no supports")
ros_f = [mesh_f(teeth_B, "rosette_teeth"),
         dict(op="add", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=R_POCK - 0.3, **{"from": X_YI + 0.01, "to": X_RB}),
         dict(op="add", shape="box", min=[X_YI + 0.01, Y_P - 3.0, ZP + 24.5], max=[X_RB, Y_P + 3.0, ZP + R_POCK + 2.85]),
         dict(op="cut", shape="cylinder", c=[0, Y_P, ZP], axis="x", r=SHANK_R + 1.0, **{"from": X_T - 5, "to": X_RB + 1})]
part("tilt_rosette", ros_f, role="other", color=[200, 150, 60], print_orientation={"down": [1, 0, 0]},
     check="its 30 teeth are crisp; it drops into the yoke's pocket with the tab in the slot",
     fit_how="print it teeth up")
joints.append(dict(a="tilt_rosette", b="yoke", type="glued", located_by="its rim in the yoke's round pocket (0.3 mm) and its key tab in the slot"))

# --- mast ---------------------------------------------------------------------------------------------------------------
MAST_Z0, MAST_Z1 = Z_C - COL_H + 10.0, Z_C + SOCK_D
mast_f = [prism("z", MAST_Z0, MAST_Z1, poly(at_c(mast_pts()))),
          drill([X_C, Y_C - 10, PIN_Z], [X_C, Y_C + 10, PIN_Z], 1.0)]
part("mast", mast_f, role="shaft", color=[60, 64, 72], print_orientation={"down": [0, -1, 0]},
     check="slides the length of the column by hand", fit_how="print it lying on a flat side")
joints.append(dict(a="mast", b="yoke", type="glued", located_by="its top in the yoke's socket (0.15 mm) and the cross pin"))
L_MP = 2 * YW - 1.2 - 1.0 + 1.0
part("mast_pin", [drill([X_C, Y_C - YW + 1.0, PIN_Z], [X_C, Y_C + YW - 2.2, PIN_Z], 1.0, op="add")],
     role="other", made_role="pin", print=False, color=[150, 150, 160], material=f"2 mm steel rod, cut {2 * YW - 3.2:.1f} mm long",
     ports={"axis": {"point": [_r(X_C), _r(Y_C), _r(PIN_Z)], "dir": [0, 1, 0]}})
joints += [dict(a="mast_pin", b="yoke", type="press_fit"), dict(a="mast_pin", b="mast", type="press_fit")]

# --- column -----------------------------------------------------------------------------------------------------------
Z_C0 = Z_C - COL_H
col_out = dense([(X_C + COL_R * math.cos(2 * math.pi * k / 72), Y_C + COL_R * math.sin(2 * math.pi * k / 72)) for k in range(72)], 2.0)
lobe = ((m3.CrossSection.circle(COL_R, 96) + m3.CrossSection.circle(12.0, 96).translate([-22.0, 0.0]))
        .offset(3, m3.JoinType.Round).offset(-3, m3.JoinType.Round))
LOBE_PTS = dense([(X_C + x, Y_C + y) for x, y in cs_pts(lobe)], 2.0)
Z_NUT = Z_C - 13.0
X_N0, X_N1 = X_C - 24.0, X_C - 24.0 + NUT_T
col_f = [rprism("z", Z_C0, Z_C, col_out, fe={"fillet": 2.0}, te={"chamfer": 0.8}),
         rprism("z", Z_C - 26.0, Z_C, LOBE_PTS, fe={"fillet": 2.0}, te={"chamfer": 0.8})]


def hexagon_yz(af, grow=0.0, yc=Y_C, zc=Z_NUT):   # vertex down and up (steep 60 deg faces print)
    rv = af / math.sqrt(3) + grow
    return [(yc + rv * math.cos(math.radians(30 + 60 * k)), zc + rv * math.sin(math.radians(30 + 60 * k))) for k in range(6)]


hx = hexagon_yz(NUT_AF, 0.3)
slot = hx + [(y, Z_C + 2) for y, z in hx if z > Z_NUT - 0.01]
# --- leg mounts (ears + stop face), built in the leg-0 frame and turned to 0, 120, 240 deg ------------------------
def mounts0():
    """Ears + stop face for leg 0 (+x), and the cuts (hinge pin, lock holes)."""
    px0 = X_C + R_H
    th = math.radians(TH_OPEN)
    lock_open = (px0 + LOCK_D * math.sin(th), Z_H - LOCK_D * math.cos(th))
    ear_cs = (m3.CrossSection.square([R_H + 11.5 - 10.0, Z_C - (Z_H - 6.0)]).translate([X_C + 10.0, Z_H - 6.0])
              + m3.CrossSection.circle(11.0, 96).translate([px0, Z_H])
              + m3.CrossSection.circle(4.5, 64).translate([px0, Z_H - LOCK_D])
              + m3.CrossSection.circle(4.5, 64).translate(list(lock_open))).hull()
    add = []
    for s in (1, -1):
        y0, y1 = (Y_C + EAR_IN, Y_C + EAR_IN + EAR_T_NEAR) if s > 0 else (Y_C - EAR_IN - EAR_T, Y_C - EAR_IN)
        add.append(mechanism.prism(ear_cs, "y", y0, y1))
    stop = m3.Manifold.cube([15.5 - 10.0, 2 * EAR_IN + 1.0, Z_C - (Z_H - 6.0)]).translate([X_C + 10.0, Y_C - EAR_IN - 0.5, Z_H - 6.0])
    add.append(stop)
    addm = m3.Manifold.batch_boolean(add, m3.OpType.Add)
    yb = Y_C - EAR_IN - EAR_T + 1.2           # blind: floor 1.2 mm in the -y ear
    cuts = [mechanism.shape(dict(shape="drill", p0=[px0, yb, Z_H], p1=[px0, Y_C + 20, Z_H], r=2.5, up=[0, 0, -1])),
            mechanism.shape(dict(shape="drill", p0=[px0, yb, Z_H - LOCK_D], p1=[px0, Y_C + 20, Z_H - LOCK_D], r=1.05, up=[0, 0, -1])),
            mechanism.shape(dict(shape="drill", p0=[lock_open[0], yb, lock_open[1]], p1=[lock_open[0], Y_C + 20, lock_open[1]], r=1.05, up=[0, 0, -1]))]
    return addm, m3.Manifold.batch_boolean(cuts, m3.OpType.Add), lock_open


leg0 = leg_body_at(Z_H)
PIN0 = [X_C + R_H, Y_C, Z_H]
mounts_add0, mounts_cut0, LOCK_OPEN0 = mounts0()
legs, mount_adds, mount_cuts = [], [], []
SIDE = {0: 1.0, 1: -1.0, 2: 1.0}      # which side of each leg the pins go in from (away from the clamp lobe)


def mirror_y(m):
    return m.translate([0, -Y_C, 0]).mirror([0, 1, 0]).translate([0, Y_C, 0])


for k, phi in enumerate((0.0, 120.0, 240.0)):
    c = [X_C, Y_C, 0.0]
    ma, mc = (mounts_add0, mounts_cut0) if SIDE[k] > 0 else (mirror_y(mounts_add0), mirror_y(mounts_cut0))
    mount_adds.append(rot_about(ma, [0, 0, 1], phi, c))
    mount_cuts.append(rot_about(mc, [0, 0, 1], phi, c))
    lg = rot_about(rot_about(leg0, [0, -1, 0], TH_OPEN, PIN0), [0, 0, 1], phi, c)
    legs.append(lg)
col_f += [mesh_f(m3.Manifold.batch_boolean(mount_adds, m3.OpType.Add), "column_ears"),
          prism("z", Z_C0 - 1, Z_C + 1, poly(at_c(mast_pts(SLIDE))), op="cut"),
          prism("x", X_N0 - 0.3, X_N1 + 0.3, {"hull_points": [[_r(a), _r(b)] for a, b in slot]}, op="cut"),
          prism("x", X_C - 36, X_C - 8, teardrop_yz(R_TH + ECC + 0.3, (Y_C, Z_NUT), up=(0.0, -1.0)), op="cut"),
          mesh_f(m3.Manifold.batch_boolean(mount_cuts, m3.OpType.Add), "column_ear_holes", op="cut")]
part("column", col_f, role="frame", color=[60, 64, 72], print_orientation={"down": [0, 0, 1]},
     check="the mast slides through it; the nut drops into its slot; the leg ears are clean",
     fit_how="print it standing on its crown (top end down): ears and collar on the bed, no supports")
steps.insert(0, dict(parts=["column"]))
steps.insert(1, dict(parts=["clamp_nut"], move="-z", note="drop the nut into the slot in the collar (a point down)"))
nut_f = [prism("x", X_N0, X_N1, poly(hexagon_yz(NUT_AF))),
         mesh_f(thread_x("nut_thread", R_TH + TH_CLEAR, X_N0 - 1, X_N1 + 1, yc=Y_C, zc=Z_NUT), "nut_thread", op="cut")]
nut_f += [dict(op="cut", shape="cylinder", c=[0, Y_C, Z_NUT], axis="x", r=R_TH + ECC + 1.0, r_to=R_TH - 1.0, **{"from": X_N0 - 0.01, "to": X_N0 + 2.0}),
          dict(op="cut", shape="cylinder", c=[0, Y_C, Z_NUT], axis="x", r=R_TH - 1.0, r_to=R_TH + ECC + 1.0, **{"from": X_N1 - 2.0, "to": X_N1 + 0.01})]
part("clamp_nut", nut_f, role="other", color=[200, 150, 60], print_orientation={"down": [1, 0, 0]},
     check="the thumbscrew turns through it by hand", fit_how="print it flat")
joints.append(dict(a="clamp_nut", b="column", type="keyed", located_by="its hexagon in the collar's slot (0.3 mm)"))
TS_TIP = X_C - MAST_H
TS_K1 = X_C - 34.5
ts_f = [mesh_f(thread_x("ts_thread", R_TH, TS_K1 - 0.5, TS_TIP, yc=Y_C, zc=Z_NUT), "ts_thread"),
        dict(op="add", shape="cylinder", c=[0, Y_C, Z_NUT], axis="x", r=13.0, **{"from": TS_K1 - 11.0, "to": TS_K1})]
ts_f += [dict(op="cut", shape="cylinder", c=[0, Y_C + 13 * math.cos(a), Z_NUT + 13 * math.sin(a)], axis="x", r=2.6,
              **{"from": TS_K1 - 12, "to": TS_K1 + 1}) for a in (2 * math.pi * k / 8 for k in range(8))]
part("thumbscrew", ts_f, role="knob", color=[200, 150, 60], print_orientation={"down": [-1, 0, 0]},
     check="turns in by hand; its tip presses the mast's flat side", fit_how="print it knob down")
joints.append(dict(a="thumbscrew", b="clamp_nut", type="running", located_by="its thread"))
steps.insert(2, dict(parts=["thumbscrew"], move="+x", screw={"point": [0.0, _r(Y_C), _r(Z_NUT)], "pitch": PITCH},
                     note="screw it in until its tip just shows in the bore"))
free.append(dict(part="thumbscrew", turn="x", point=[0.0, _r(Y_C), _r(Z_NUT)], pitch=PITCH,
                 why="the slide clamp: loosen it to slide the mast, tighten it onto the mast's flat side"))

# --- legs, hinge pins, lock pins ---------------------------------------------------------------------------------------
yb = Y_C - EAR_IN - EAR_T + 1.2
L_HP = (Y_C + EAR_IN + EAR_T_NEAR) - yb
L_LP = L_HP + 2.0
st = 3
for k, phi in enumerate((0.0, 120.0, 240.0)):
    c = [X_C, Y_C, 0.0]
    t0 = np.array([-math.sin(math.radians(phi)), math.cos(math.radians(phi)), 0.0])      # leg-0 +y turned
    t = t0 * SIDE[k]                                                                      # the way the pins come out
    ybk = Y_C + SIDE[k] * (yb - Y_C)
    pin_w = rot_about(m3.Manifold.cylinder(1, 1, 1).translate(PIN0), [0, 0, 1], phi, c)
    pw = np.array(rot_about(m3.Manifold.sphere(0.01).translate(PIN0), [0, 0, 1], phi, c).bounding_box()[:3]) + 0.01
    part(f"leg_{k}", [mesh_f(legs[k], f"leg_{k}")], role="arm", color=[60, 64, 72],
         print_orientation={"down": [_r(-t0[0]), _r(-t0[1]), 0.0]},
         check="swings freely on its pin between the ears", fit_how="print it lying flat (chamfered side down)")
    hp0 = rot_about(m3.Manifold.sphere(0.01).translate([PIN0[0], ybk, Z_H]), [0, 0, 1], phi, c)
    hp0 = np.array(hp0.bounding_box()[:3]) + 0.01
    part(f"hinge_pin_{k}", [drill(hp0, hp0 + t * L_HP, 2.5, op="add")], role="other", made_role="pin", print=False,
         color=[150, 150, 160], material=f"5 mm steel rod, cut {L_HP:.1f} mm long",
         ports={"axis": {"point": [_r(v) for v in pw], "dir": [_r(v) for v in t]}})
    lk0 = rot_about(m3.Manifold.sphere(0.01).translate([LOCK_OPEN0[0], ybk, LOCK_OPEN0[1]]), [0, 0, 1], phi, c)
    lk0 = np.array(lk0.bounding_box()[:3]) + 0.01
    part(f"lock_pin_{k}", [drill(lk0, lk0 + t * L_LP, 1.0, op="add")], role="other", made_role="pin", print=False,
         color=[150, 150, 160], material=f"2 mm steel rod, cut {L_LP:.1f} mm long (removable lock pin)",
         ports={"axis": {"point": [_r(v) for v in lk0], "dir": [_r(v) for v in t]}})
    joints += [dict(a=f"hinge_pin_{k}", b="column", type="press_fit"),
               dict(a=f"leg_{k}", b=f"hinge_pin_{k}", type="hinge_pin"),
               dict(a=f"lock_pin_{k}", b="column", type="sliding", located_by="its two holes in the ears and the leg's hole")]
    axis = dict(point=[_r(v) for v in pw], dir=[_r(-v) for v in t0])  # positive = the leg opens outward
    motions += [dict(name=f"leg {k} folds up (lock pin pulled)", parts=[f"leg_{k}"], axis=axis, to_deg=-_r(TH_OPEN),
                     expect="clear", ignore=[{"part": f"lock_pin_{k}", "why": "pulled out before folding"}]),
                dict(name=f"leg {k} locked open: cannot fold", parts=[f"leg_{k}"], axis=axis, to_deg=-6, expect="blocked",
                     blocked_by=[f"lock_pin_{k}"]),
                dict(name=f"leg {k} cannot open past {TH_OPEN:.0f} deg", parts=[f"leg_{k}"], axis=axis, to_deg=6,
                     expect="blocked", blocked_by=[f"lock_pin_{k}"]),
                dict(name=f"lock pin {k} pulled", parts=[f"lock_pin_{k}"], slide=True,
                     axis=dict(point=[_r(v) for v in lk0], dir=[_r(v) for v in t]), to_deg=L_LP + 1, expect="clear")]
    steps.insert(st, dict(parts=[f"leg_{k}"], move=[_r(-math.cos(math.radians(phi))), _r(-math.sin(math.radians(phi))), 0.0],
                          note=f"leg {k}: slide its knuckle in between the ears (chamfered side either way)"))
    steps.insert(st + 1, dict(parts=[f"hinge_pin_{k}"], move=[_r(-v) for v in t], note="press the 5 mm pin in until it bottoms in the far ear"))
    steps.insert(st + 2, dict(parts=[f"lock_pin_{k}"], move=[_r(-v) for v in t], note="open the leg, push the lock pin through"))
    st += 3
    if abs(t[1]) > 0.99:
        free.append(dict(part=f"lock_pin_{k}", move="+y" if t[1] > 0 else "-y", why="pulled out by hand to fold the leg"))

# --- stand assembly order, then the head -------------------------------------------------------------------------------
steps.insert(st, dict(parts=["mast"], move="-z", note="slide the mast down into the column until it stops"))
steps.insert(st + 1, dict(parts=["yoke"], move="-z", note="the yoke's socket over the mast top"))
steps.insert(st + 2, dict(parts=["mast_pin"], move="+y", note="press the 2 mm pin through the yoke and mast until it bottoms"))
steps.insert(st + 3, dict(parts=["tilt_rosette"], move="+x", note="glue the rosette into the yoke's pocket, tab in the slot, teeth out"))
# head steps (can is already in the list): inserts come from the idiom; then strips, fabric, frame (screws by the idiom)
steps.append(dict(parts=[f"led_{k + 1}" for k in range(len(LANES))], move="+y", note="stick the strips between the lane ribs; solder the leads; feed the cable out of the back hole and weave it round the three posts"))
steps.append(dict(parts=["fabric"], move="+y", note="lay the fabric over the face, holes on the inserts"))
steps.append(dict(parts=["face_frame"], move="+y", note="frame on, groove over the ridge; screws in next, crosswise, snug"))
steps.append(dict(parts=["tilt_knob"], move="-x", screw={"point": [0.0, _r(Y_P), _r(ZP)], "pitch": PITCH},
                  note="hang the head on the yoke (bolt through the rosette and the yoke), then the knob on and tight"))
free.append(dict(part="tilt_knob", turn="x", point=[0.0, _r(Y_P), _r(ZP)], pitch=PITCH,
                 why="the tilt clamp: one turn back lifts the teeth apart to change the angle"))
free.append(dict(part="mast", move="+z", why="height adjust: slides up when the thumbscrew is loosened"))

HEAD = ["can", "fabric", "face_frame", "bolt", "tilt_knob"] + [f"led_{k + 1}" for k in range(len(LANES))]
HEAD_HW = [f"fs{i + 1}_{w}" for i in range(len(SCREWS)) for w in ("screw", "insert")]
UPPER = ["mast", "yoke", "tilt_rosette", "mast_pin"]
HW_IGN = [{"part": n, "why": "pressed into the can / screwed through the frame: turns with the head"} for n in HEAD_HW]
motions += [dict(name="tilt up to +60 deg (knob loosened)", parts=HEAD, axis=AXIS_T, to_deg=60, expect="clear",
                 ignore=[{"part": "tilt_rosette", "why": "a turn of the knob lifts the head 2.3 mm off the rosette's teeth to re-index"}]
                 + HW_IGN),
            dict(name="tilt down to -36 deg (knob loosened)", parts=HEAD, axis=AXIS_T, to_deg=-36, expect="clear",
                 ignore=[{"part": "tilt_rosette", "why": "a turn of the knob lifts the head 2.3 mm off the rosette's teeth to re-index"}]
                 + HW_IGN),
            dict(name="knob tight: the teeth lock the tilt", parts=HEAD, axis=AXIS_T, to_deg=4, expect="blocked",
                 blocked_by=["tilt_rosette"], ignore=HW_IGN),
            dict(name="raise the light 100 mm (thumbscrew loosened)", parts=UPPER + HEAD + HEAD_HW, slide=True,
                 axis=dict(point=[_r(X_C), _r(Y_C), _r(Z_C)], dir=[0, 0, 1]), to_deg=100, expect="clear"),
            dict(name="lowest height: the yoke sits on the column", parts=UPPER + HEAD + HEAD_HW, slide=True,
                 axis=dict(point=[_r(X_C), _r(Y_C), _r(Z_C)], dir=[0, 0, -1]), to_deg=3, expect="blocked", blocked_by=["column"])]
spec = dict(name="can_studio_light", units="mm", table_z=0.0, kind="object", stands=True,
            ground_contacts=["leg_0", "leg_1", "leg_2"], ground="column", parts=parts, joints=joints,
            assembly=steps, motions=motions, free=free, idioms=idioms, print_strict=True,
            sourcing={"mode": "on_hand", "on_hand": [{"kind": "screw", "thread": "M3"}, {"kind": "insert", "thread": "M3"},
                                                      {"kind": "screw", "thread": "M5"}, {"kind": "rod", "d": 2.0, "len": 1000},
                                                      {"kind": "rod", "d": 5.0, "len": 1000}]})
(OUT / "raw.json").write_text(json.dumps(spec, indent=1))
info = dict(Z_H=_r(Z_H), Z_C=_r(Z_C), Z_A=_r(Z_A), ZP=_r(ZP), R_SWEEP=_r(R_SWEEP), TH_OPEN=_r(TH_OPEN), TH_STOP=_r(TH_STOP),
            Y_P=Y_P, X_C=X_C, A_T=round(A_T, 5), tooth_h_at_rout=_r(2 * A_T * R_TOUT * (1 - TRUNC)), L_HP=_r(L_HP), L_LP=_r(L_LP),
            L_MP=_r(2 * YW - 3.2), lock_open=[_r(v) for v in LOCK_OPEN0])
(OUT / "info.json").write_text(json.dumps(info, indent=1))
print(json.dumps(info))
