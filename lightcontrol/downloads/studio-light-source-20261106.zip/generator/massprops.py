"""Mass, centre of mass, tilt torque and tip angles of a generated spec: massprops.py <dir> [--json]"""
import json, math, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, "/Users/kevincorsmeier/Documents/GitHub/drawBot/.claude/worktrees/electrical/drawBotStudyService")
from study_service.partmodel import expand, mechanism as M

S = Path(sys.argv[1])
spec = expand.expand(json.loads((S / "raw.json").read_text()))
info = json.loads((S / "info.json").read_text())
b = M.build(spec)
meta = {p["name"]: p for p in spec["parts"]}
STEEL, PLA = 7.85, 1.24
mass, com = {}, {}
for n, m in b.parts.items():
    p = meta[n]
    vol = m.volume() / 1000.0
    # centroid of the solid
    me = m.to_mesh()
    v = np.asarray(me.vert_properties)[:, :3]
    f = np.asarray(me.tri_verts)
    a, b_, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    vv = np.einsum("ij,ij->i", a, np.cross(b_, c)) / 6.0
    cen = ((a + b_ + c) / 4.0 * vv[:, None]).sum(0) / vv.sum()
    mat = str(p.get("material", "")).lower()
    if p.get("mass_g"):
        g = float(p["mass_g"])
    elif n == "fabric":
        g = 0.2 * 0.2 * 110.0           # ~110 g/m2 diffusion cloth
    elif p.get("print", True) is False:
        g = vol * (STEEL if ("steel" in mat or "screw" in mat or "shcs" in mat) else 8.4 if "insert" in mat else 1.2)
    else:
        g = vol * PLA
    mass[n], com[n] = g, cen
HEAD = [n for n in b.parts if n in ("can", "fabric", "face_frame", "bolt", "tilt_knob") or n.startswith("led_") or n.startswith("fs")]
UPPER = HEAD + ["yoke", "tilt_rosette", "mast", "mast_pin"]
ALL = list(b.parts)


def cm(names):
    tot = sum(mass[n] for n in names)
    return tot, sum(mass[n] * com[n] for n in names) / tot


mh, ch = cm(HEAD)
mu, cu = cm(UPPER)
ma, ca = cm(ALL)
yp, zp = info["Y_P"], info["ZP"]
d = math.hypot(ch[1] - yp, ch[2] - zp)
torque = mh / 1000 * 9.81 * d / 1000         # N m, the head's weight about the tilt axis (worst angle)
# tip: the three feet (lowest points of the legs)
feet = []
for k in range(3):
    v = np.asarray(b.parts[f"leg_{k}"].to_mesh().vert_properties)[:, :3]
    feet.append(v[v[:, 2].argmin()])
feet = np.array(feet)
P = ca[:2]


def edge_margin(P):
    out = []
    for i in range(3):
        A, B = feet[i, :2], feet[(i + 1) % 3, :2]
        e = B - A
        nrm = np.array([e[1], -e[0]]) / np.linalg.norm(e)
        cen = feet[:, :2].mean(0)
        if (cen - A) @ nrm < 0:
            nrm = -nrm
        out.append(float((P - A) @ nrm))
    return min(out)


h = ca[2]
tip = math.degrees(math.atan2(edge_margin(P), h))
# at full height (+100 mm on the upper assembly)
ca_hi = (ma * ca + mu * np.array([0, 0, 100.0])) / ma
tip_hi = math.degrees(math.atan2(edge_margin(ca_hi[:2]), ca_hi[2]))
printed = {n: round(mass[n], 1) for n in b.parts if meta[n].get("print", True) is not False}
out = dict(head_g=round(mh, 1), head_com=[round(x, 2) for x in ch], pivot=[info.get("X_C"), yp, zp], head_off_mm=round(d, 2),
           head_torque_Nm=round(torque, 3), upper_g=round(mu, 1), upper_com=[round(x, 2) for x in cu], total_g=round(ma, 1),
           total_com=[round(x, 2) for x in ca], feet=[[round(x, 1) for x in f_] for f_ in feet], tip_deg=round(tip, 1),
           tip_deg_raised_100=round(tip_hi, 1), printed_g=printed, printed_total_g=round(sum(printed.values()), 1),
           bought_g=round(sum(mass[n] for n in b.parts if n not in printed), 1),
           can_head_printed_g=round(sum(printed.get(n, 0) for n in HEAD), 1))
print(json.dumps(out, indent=1, default=float))
if "--json" in sys.argv:
    (S / "massprops.json").write_text(json.dumps(out, indent=1, default=float))
