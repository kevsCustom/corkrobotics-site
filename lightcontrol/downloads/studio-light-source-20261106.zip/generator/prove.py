"""Extra proofs the pipeline has no check for (prove.py <dir with raw.json + info.json>):
 - the tilt teeth seat at every 12 deg index (-36..+60) and clash half a tooth off (locked when tight);
 - 2.3 mm of knob back-off (0.77 turn) lets the head turn past the teeth;
 - the head clears the stand over -90..+90 deg;
 - each leg's lock pin also locks it FOLDED (the stowed holes line up; the folded leg cannot swing out with the pin in);
 - the slide clamp's thumbscrew tip stays on the mast's flat over the whole 100 mm of height travel."""
import json, math, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, "/Users/kevincorsmeier/Documents/GitHub/drawBot/.claude/worktrees/electrical/drawBotStudyService")
from study_service.partmodel import expand, mechanism as M
import manifold3d as m3

S = Path(sys.argv[1])
spec = expand.expand(json.loads((S / "raw.json").read_text()))
info = json.loads((S / "info.json").read_text())
b = M.build(spec)
P = b.parts
V = M._vol
ax = next(mo for mo in spec["motions"] if mo["name"].startswith("tilt up"))["axis"]
HEAD = [n for n in P if n in ("can", "fabric", "face_frame", "bolt", "tilt_knob") or n.startswith("led_") or n.startswith("fs")]
STAND = [n for n in P if n not in HEAD and n != "tilt_rosette"]
head_can = P["can"]
ros = P["tilt_rosette"]
out = {"index": [], "half_tooth": [], "loosened": [], "sweep": {}, "legs": []}
rest = V(head_can ^ ros)
for k in range(-3, 6):
    deg = 12 * k
    c = M._rotate(head_can, ax["dir"], deg, ax["point"])
    seat = V(c ^ ros)
    half = V(M._rotate(head_can, ax["dir"], deg + 6, ax["point"]) ^ ros)
    out["index"].append({"deg": deg, "overlap_mm3": round(seat, 3), "seats": seat <= rest + M.OVERLAP_TOL})
    out["half_tooth"].append({"deg": deg + 6, "clash_mm3": round(half, 1), "locked": half > 5.0})
back = head_can.translate([-2.3, 0, 0])
for deg in (3, 6, 9):
    v = V(M._rotate(back, ax["dir"], deg, ax["point"]) ^ ros)
    out["loosened"].append({"deg": deg, "overlap_mm3": round(v, 3), "free": v <= M.OVERLAP_TOL})
# sweep: the whole head (less the hardware turning with it) against the stand, -90..+90 in 2 deg steps
head_all = m3.Manifold.batch_boolean([P[n] for n in HEAD], m3.OpType.Add)
stand = m3.Manifold.batch_boolean([P[n] for n in STAND], m3.OpType.Add)
worst = []
for deg in range(-90, 91, 2):
    h = M._rotate(head_all, ax["dir"], deg, ax["point"])
    v = V(h ^ stand)
    if v > M.OVERLAP_TOL:
        worst.append((deg, round(v, 1)))
out["sweep"] = {"range_deg": [-90, 90], "hits": worst}
# lowest point of the head over the sweep vs the yoke foot top
zl = min(M._rotate(head_all, ax["dir"], d, ax["point"]).bounding_box()[2] for d in range(-90, 91, 5))
out["sweep"]["head_lowest_z"] = round(zl, 1)
out["sweep"]["yoke_foot_top_z"] = info["Z_A"]
# legs: folded lock
for k in range(3):
    mo = next(m for m in spec["motions"] if m["name"].startswith(f"leg {k} folds up"))
    a = mo["axis"]
    th = mo["to_deg"]                      # -35: open -> folded
    leg_f = M._rotate(P[f"leg_{k}"], a["dir"], th, a["point"])
    pin_f = M._rotate(P[f"lock_pin_{k}"], a["dir"], th, a["point"])   # the pin through the leg's hole, folded
    col = P["column"]
    r = {"leg": k, "pin_in_folded_holes_overlap_mm3": round(V(pin_f ^ col), 3),
         "pin_vs_folded_leg_mm3": round(V(pin_f ^ leg_f), 3)}
    swing = max(V(M._rotate(leg_f, a["dir"], s, a["point"]) ^ pin_f) for s in (4, -4))
    r["folded_leg_turned_4deg_hits_pin_mm3"] = round(swing, 1)
    r["locked_folded"] = r["pin_in_folded_holes_overlap_mm3"] <= M.OVERLAP_TOL and swing > 0.5
    # folded leg clear of everything else
    others = m3.Manifold.batch_boolean([P[n] for n in P if n not in (f"leg_{k}", f"lock_pin_{k}", f"hinge_pin_{k}")], m3.OpType.Add)
    r["folded_leg_overlap_mm3"] = round(V(leg_f ^ others), 2)
    out["legs"].append(r)
# slide clamp: the screw tip on the mast at every height
ts, mast = P["thumbscrew"], P["mast"]
gaps = []
for dz in range(0, 101, 10):
    mm = mast.translate([0, 0, dz])
    gaps.append(round(V(ts ^ mm), 3))
tip_touch = max(V(ts.translate([0.3, 0, 0]) ^ mast.translate([0, 0, dz])) for dz in range(0, 101, 20))
out["slide_clamp"] = {"overlap_at_heights_mm3": gaps, "tip_presses_mast_when_turned_0.3mm": tip_touch > 0.05,
                      "height_travel_mm": 100}
(S / "prove.json").write_text(json.dumps(out, indent=1))
print(json.dumps({k: v for k, v in out.items() if k != "half_tooth"}, indent=1))
print("half tooth clash:", [h["clash_mm3"] for h in out["half_tooth"]])
